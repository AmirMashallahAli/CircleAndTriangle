import java.util.Scanner;
/**
 * Programming with methods
 */
public class MyProgram
{
    public void runMyProgram()
    { 
        Scanner reader = new Scanner(System.in);
        double height1 = 4.5;
        System.out.println("Please enter the base of your triangle: ");
        double base1 = reader.nextDouble();
        double AreaOfTriangle1 = 0.5 * height1 * base1;
        System.out.println("The area of your triangle = " + AreaOfTriangle1);
        
        double base2 = 1;
        double height2 = 6;
        for (int i=0;i<5;i++)
        {
        double AreaOfTriangle2 = 0.5 * base2 * height2;
        System.out.println("The area of you triangle = " + AreaOfTriangle2);
        if (AreaOfTriangle2 < 20)
        {
            System.out.println("Small Triangle");
        }
        else
        {
            System.out.println("Large Triangle");
        }
        base2 = base2 + 3;
    }
}
    //Define as many subordinate methods as you like

    
    public static void main(String[] args)
    { 
        MyProgram prog = new MyProgram();  //create an object
        prog.runMyProgram();  //invoke the top method

    }
    
    
}
