import java.util.Scanner;
/**
 * Programming with methods
 */
public class MyProgram
{
    public void runMyProgram()
    { 
        Scanner reader = new Scanner(System.in);
        //Task 2
        double height1 = 4.5;
        System.out.println("Please enter the base of your triangle: ");
        double base1 = reader.nextDouble();
        double AreaOfTriangle1 = 0.5 * height1 * base1;
        System.out.println("The area of your triangle = " + AreaOfTriangle1);
        
        //Task 3
        double base2 = 1;
        double height2 = 6;
        for (int i=0;i<5;i++)
        {
        double AreaOfTriangle2 = 0.5 * base2 * height2;
        System.out.println("The area of you triangle = " + AreaOfTriangle2);
        if (AreaOfTriangle2 < 20)
        {
            System.out.println("Small Triangle");
        }
        else
        {
            System.out.println("Large Triangle");
        }
        base2 = base2 + 3;
    }
    
        //Task 5
        double result = areaOfTriangle(base1,height1);
        System.out.println("The area of a triangle with height "+ height1+ " and base "+ base1+ " is "+ result);
    
        //Task 7
        System.out.println("Please enter the radius of your circle: ");
        double AC = areaOfCircle(reader.nextDouble());
        System.out.println("The area of your circle = "+ AC);
        
        //Task 8
        double AreaOfCircle = areaOfCircle(10);
        double AreaOfTriangle3 = areaOfTriangle(20,10);
        double ShadedArea = AreaOfCircle - AreaOfTriangle3;
        System.out.println("The area of the shaded path = "+ ShadedArea);
        
        //Task 9
        double radius = 10;
    while (radius <= 20)
        {
            System.out.println("The area of the circle with a radius of "+ radius + "cm = "+ areaOfCircle(radius) + "cm²");
            radius = radius + 2;
        }
        
}
    //Define as many subordinate methods as you like
double areaOfTriangle(double base, double height)
{
    double TriangleArea = 0.5 * base * height;
    return TriangleArea;
}

double areaOfCircle(double radius)
{
    double CircleArea = Math.PI * radius * radius;
    return CircleArea;
}

    public static void main(String[] args)
    { 
        MyProgram prog = new MyProgram();  //create an object
        prog.runMyProgram();  //invoke the top method

    }
    
    
}
