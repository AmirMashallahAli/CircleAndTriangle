import java.util.Scanner;
/**
 * Programming with methods
 */
public class MyProgram
{
    public void runMyProgram()
    { 
        Scanner reader = new Scanner(System.in);
        
        //Task10
        System.out.println("0. Quit");
        System.out.println("1. area of a Circle");
        System.out.println("2. area of a Triangle");
        System.out.println("Please enter a number from the choices above: ");
        int choice = reader.nextInt();
        
        while (choice!=0)
        {
            if (choice==1)
            {
                System.out.println("Please enter the radius of your circle: ");
                double RadiusOfCircle = reader.nextDouble();
                System.out.println("The area of your circle = "+ areaOfCircle(RadiusOfCircle));
                
                System.out.println("Please enter the number of your choice: ");
                choice = reader.nextInt();
            }
            else if (choice==2)
            {
                System.out.println("Please enter the base of your triangle: ");
                double BaseOfTriangle = reader.nextDouble();
                System.out.println("Please enter the height of your triangle: ");
                double HeightOfTriangle = reader.nextDouble();
                System.out.println("The area of your triangle = "+ areaOfTriangle(BaseOfTriangle,HeightOfTriangle));
                
                System.out.println("Please enter the number of your choice: ");
                choice = reader.nextInt();
            }
            else
            {
                System.out.println("That is not part of the options, please choose again: ");
                choice = reader.nextInt();
            }
    }
    if (choice ==0)
    {
        System.out.println("Thank You");
    }
    
}
    //Define as many subordinate methods as you like
    double areaOfTriangle(double base, double height)
{
    double TriangleArea = 0.5 * base * height;
    return TriangleArea;
}

double areaOfCircle(double radius)
{
    double CircleArea = Math.PI * radius * radius;
    return CircleArea;
}
    
    public static void main(String[] args)
    { 
        MyProgram prog = new MyProgram();  //create an object
        prog.runMyProgram();  //invoke the top method

    }
    
    
}
